package com.frxhaikal_plg.ingrevia.data.local.model

data class UserInfo(
    val height: Int,
    val weight: Int,
    val age: Int,
    val activityLevel: Int,
    val gender: String
)

